﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.body_Box = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.server_Box = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.server_Connect = New System.Windows.Forms.Button()
        Me.server_Recieve = New System.Windows.Forms.TextBox()
        Me.sever_Send = New System.Windows.Forms.TextBox()
        Me.server_Send = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.server_Status = New System.Windows.Forms.Label()
        Me.ServerTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.hit_diagram = New System.Windows.Forms.Timer(Me.components)
        Me.colorReset = New System.Windows.Forms.Label()
        Me.score = New System.Windows.Forms.Label()
        Me.Start = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IPFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TCPToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TCPServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TCPClientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoiceRecognitionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControlsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DocumentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ipAddress1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.hotName = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.body_Box, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.server_Box, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'body_Box
        '
        Me.body_Box.BackColor = System.Drawing.Color.White
        Me.body_Box.Location = New System.Drawing.Point(198, 219)
        Me.body_Box.Name = "body_Box"
        Me.body_Box.Size = New System.Drawing.Size(136, 176)
        Me.body_Box.TabIndex = 0
        Me.body_Box.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Location = New System.Drawing.Point(340, 219)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(52, 107)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Location = New System.Drawing.Point(140, 219)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(52, 107)
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.White
        Me.PictureBox4.Location = New System.Drawing.Point(225, 131)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(87, 82)
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox5.Location = New System.Drawing.Point(12, 29)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(928, 1)
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox6.Location = New System.Drawing.Point(736, 33)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(1, 474)
        Me.PictureBox6.TabIndex = 5
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox7.Location = New System.Drawing.Point(270, 33)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(1, 474)
        Me.PictureBox7.TabIndex = 6
        Me.PictureBox7.TabStop = False
        '
        'server_Box
        '
        Me.server_Box.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.server_Box.Location = New System.Drawing.Point(752, 194)
        Me.server_Box.Name = "server_Box"
        Me.server_Box.Size = New System.Drawing.Size(160, 41)
        Me.server_Box.TabIndex = 19
        Me.server_Box.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(748, 279)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Recieve"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(756, 257)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Send"
        '
        'server_Connect
        '
        Me.server_Connect.Location = New System.Drawing.Point(748, 145)
        Me.server_Connect.Name = "server_Connect"
        Me.server_Connect.Size = New System.Drawing.Size(164, 43)
        Me.server_Connect.TabIndex = 16
        Me.server_Connect.Text = "Connect"
        Me.server_Connect.UseVisualStyleBackColor = True
        '
        'server_Recieve
        '
        Me.server_Recieve.BackColor = System.Drawing.SystemColors.InfoText
        Me.server_Recieve.ForeColor = System.Drawing.Color.White
        Me.server_Recieve.Location = New System.Drawing.Point(801, 276)
        Me.server_Recieve.Name = "server_Recieve"
        Me.server_Recieve.Size = New System.Drawing.Size(100, 20)
        Me.server_Recieve.TabIndex = 15
        '
        'sever_Send
        '
        Me.sever_Send.BackColor = System.Drawing.SystemColors.InfoText
        Me.sever_Send.ForeColor = System.Drawing.Color.White
        Me.sever_Send.Location = New System.Drawing.Point(801, 250)
        Me.sever_Send.Name = "sever_Send"
        Me.sever_Send.Size = New System.Drawing.Size(100, 20)
        Me.sever_Send.TabIndex = 14
        '
        'server_Send
        '
        Me.server_Send.Location = New System.Drawing.Point(748, 302)
        Me.server_Send.Name = "server_Send"
        Me.server_Send.Size = New System.Drawing.Size(164, 23)
        Me.server_Send.TabIndex = 13
        Me.server_Send.Text = "Send"
        Me.server_Send.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(743, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(147, 29)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "TCP- Server"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(749, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 16)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Status:"
        '
        'server_Status
        '
        Me.server_Status.AutoSize = True
        Me.server_Status.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.server_Status.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.server_Status.Location = New System.Drawing.Point(809, 74)
        Me.server_Status.Name = "server_Status"
        Me.server_Status.Size = New System.Drawing.Size(103, 16)
        Me.server_Status.TabIndex = 22
        Me.server_Status.Text = "Disconnected"
        '
        'ServerTimer
        '
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.SystemColors.InfoText
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(536, 68)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(194, 420)
        Me.ListBox1.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(543, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 29)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Log:"
        '
        'hit_diagram
        '
        Me.hit_diagram.Interval = 1000
        '
        'colorReset
        '
        Me.colorReset.AutoSize = True
        Me.colorReset.BackColor = System.Drawing.Color.White
        Me.colorReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.colorReset.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.colorReset.Location = New System.Drawing.Point(6, 457)
        Me.colorReset.Name = "colorReset"
        Me.colorReset.Size = New System.Drawing.Size(30, 31)
        Me.colorReset.TabIndex = 25
        Me.colorReset.Text = "0"
        '
        'score
        '
        Me.score.AutoSize = True
        Me.score.BackColor = System.Drawing.Color.Black
        Me.score.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.score.Location = New System.Drawing.Point(485, 48)
        Me.score.Name = "score"
        Me.score.Size = New System.Drawing.Size(37, 39)
        Me.score.TabIndex = 26
        Me.score.Text = "0"
        '
        'Start
        '
        Me.Start.Location = New System.Drawing.Point(748, 331)
        Me.Start.Name = "Start"
        Me.Start.Size = New System.Drawing.Size(164, 164)
        Me.Start.TabIndex = 28
        Me.Start.TabStop = False
        Me.Start.Text = "Start"
        Me.Start.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilesToolStripMenuItem, Me.TCPToolsToolStripMenuItem, Me.VoiceRecognitionToolStripMenuItem, Me.DocumentsToolStripMenuItem, Me.InformationToolStripMenuItem, Me.HelpToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(929, 24)
        Me.MenuStrip1.TabIndex = 47
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FilesToolStripMenuItem
        '
        Me.FilesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IPFilesToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.FilesToolStripMenuItem.Name = "FilesToolStripMenuItem"
        Me.FilesToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.FilesToolStripMenuItem.Text = "Files"
        '
        'IPFilesToolStripMenuItem
        '
        Me.IPFilesToolStripMenuItem.Name = "IPFilesToolStripMenuItem"
        Me.IPFilesToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.IPFilesToolStripMenuItem.Text = "IP Files"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(110, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'TCPToolsToolStripMenuItem
        '
        Me.TCPToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TCPServerToolStripMenuItem, Me.TCPClientToolStripMenuItem})
        Me.TCPToolsToolStripMenuItem.Name = "TCPToolsToolStripMenuItem"
        Me.TCPToolsToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.TCPToolsToolStripMenuItem.Text = "TCP Tools"
        '
        'TCPServerToolStripMenuItem
        '
        Me.TCPServerToolStripMenuItem.Name = "TCPServerToolStripMenuItem"
        Me.TCPServerToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.TCPServerToolStripMenuItem.Text = "TCP Server"
        '
        'TCPClientToolStripMenuItem
        '
        Me.TCPClientToolStripMenuItem.Name = "TCPClientToolStripMenuItem"
        Me.TCPClientToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.TCPClientToolStripMenuItem.Text = "TCP Client"
        '
        'VoiceRecognitionToolStripMenuItem
        '
        Me.VoiceRecognitionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogToolStripMenuItem, Me.ControlsToolStripMenuItem})
        Me.VoiceRecognitionToolStripMenuItem.Name = "VoiceRecognitionToolStripMenuItem"
        Me.VoiceRecognitionToolStripMenuItem.Size = New System.Drawing.Size(114, 20)
        Me.VoiceRecognitionToolStripMenuItem.Text = "Voice Recognition"
        '
        'LogToolStripMenuItem
        '
        Me.LogToolStripMenuItem.Name = "LogToolStripMenuItem"
        Me.LogToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.LogToolStripMenuItem.Text = "Log"
        '
        'ControlsToolStripMenuItem
        '
        Me.ControlsToolStripMenuItem.Name = "ControlsToolStripMenuItem"
        Me.ControlsToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.ControlsToolStripMenuItem.Text = "Controls"
        '
        'DocumentsToolStripMenuItem
        '
        Me.DocumentsToolStripMenuItem.Name = "DocumentsToolStripMenuItem"
        Me.DocumentsToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.DocumentsToolStripMenuItem.Text = "Documents"
        '
        'InformationToolStripMenuItem
        '
        Me.InformationToolStripMenuItem.Name = "InformationToolStripMenuItem"
        Me.InformationToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.InformationToolStripMenuItem.Text = "Information"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ipAddress1
        '
        Me.ipAddress1.AutoSize = True
        Me.ipAddress1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ipAddress1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ipAddress1.Location = New System.Drawing.Point(809, 116)
        Me.ipAddress1.Name = "ipAddress1"
        Me.ipAddress1.Size = New System.Drawing.Size(92, 16)
        Me.ipAddress1.TabIndex = 49
        Me.ipAddress1.Text = "000.000.0.00"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(749, 116)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 16)
        Me.Label7.TabIndex = 48
        Me.Label7.Text = "IP Add:"
        '
        'hotName
        '
        Me.hotName.AutoSize = True
        Me.hotName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hotName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.hotName.Location = New System.Drawing.Point(794, 96)
        Me.hotName.Name = "hotName"
        Me.hotName.Size = New System.Drawing.Size(92, 16)
        Me.hotName.TabIndex = 51
        Me.hotName.Text = "000.000.0.00"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(749, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 16)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "Host:"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox1.Location = New System.Drawing.Point(529, 36)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1, 474)
        Me.PictureBox1.TabIndex = 52
        Me.PictureBox1.TabStop = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 496)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(929, 22)
        Me.StatusStrip1.TabIndex = 53
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Black
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label6.Location = New System.Drawing.Point(369, 46)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(124, 39)
        Me.Label6.TabIndex = 54
        Me.Label6.Text = "Score:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlText
        Me.ClientSize = New System.Drawing.Size(929, 518)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.hotName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.ipAddress1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Start)
        Me.Controls.Add(Me.score)
        Me.Controls.Add(Me.colorReset)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.server_Status)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.server_Box)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.server_Connect)
        Me.Controls.Add(Me.server_Recieve)
        Me.Controls.Add(Me.sever_Send)
        Me.Controls.Add(Me.server_Send)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.body_Box)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "Fencer Control"
        CType(Me.body_Box, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.server_Box, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents body_Box As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents server_Box As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents server_Connect As Button
    Friend WithEvents server_Recieve As TextBox
    Friend WithEvents sever_Send As TextBox
    Friend WithEvents server_Send As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents server_Status As Label
    Friend WithEvents ServerTimer As Timer
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents hit_diagram As Timer
    Friend WithEvents colorReset As Label
    Friend WithEvents score As Label
    Friend WithEvents Start As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IPFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents TCPToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TCPServerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TCPClientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VoiceRecognitionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ControlsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DocumentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InformationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ipAddress1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents hotName As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents Label6 As Label
End Class
