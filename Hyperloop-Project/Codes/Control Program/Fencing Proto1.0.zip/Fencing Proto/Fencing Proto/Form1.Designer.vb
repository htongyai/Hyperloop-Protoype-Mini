﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FencingSim
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TimerLabel = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StartButton = New System.Windows.Forms.Button()
        Me.mst = New System.Windows.Forms.Label()
        Me.sss = New System.Windows.Forms.Label()
        Me.sst = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.mt = New System.Windows.Forms.Label()
        Me.ms = New System.Windows.Forms.Label()
        Me.HIT2 = New System.Windows.Forms.Label()
        Me.HIT1 = New System.Windows.Forms.Label()
        Me.P1Action = New System.Windows.Forms.TextBox()
        Me.ch2 = New System.Windows.Forms.PictureBox()
        Me.ch1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.P2Action = New System.Windows.Forms.TextBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        CType(Me.ch2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ch1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TimerLabel
        '
        Me.TimerLabel.AutoSize = True
        Me.TimerLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimerLabel.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.TimerLabel.Location = New System.Drawing.Point(1172, 9)
        Me.TimerLabel.Name = "TimerLabel"
        Me.TimerLabel.Size = New System.Drawing.Size(99, 108)
        Me.TimerLabel.TabIndex = 0
        Me.TimerLabel.Text = "0"
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(1612, 12)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(269, 105)
        Me.StartButton.TabIndex = 1
        Me.StartButton.Text = "Start"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'mst
        '
        Me.mst.AutoSize = True
        Me.mst.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mst.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.mst.Location = New System.Drawing.Point(1092, 9)
        Me.mst.Name = "mst"
        Me.mst.Size = New System.Drawing.Size(99, 108)
        Me.mst.TabIndex = 2
        Me.mst.Text = "0"
        '
        'sss
        '
        Me.sss.AutoSize = True
        Me.sss.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sss.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.sss.Location = New System.Drawing.Point(958, 9)
        Me.sss.Name = "sss"
        Me.sss.Size = New System.Drawing.Size(99, 108)
        Me.sss.TabIndex = 3
        Me.sss.Text = "0"
        '
        'sst
        '
        Me.sst.AutoSize = True
        Me.sst.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sst.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.sst.Location = New System.Drawing.Point(876, 9)
        Me.sst.Name = "sst"
        Me.sst.Size = New System.Drawing.Size(99, 108)
        Me.sst.TabIndex = 4
        Me.sst.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(1034, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 108)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = ":"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(814, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 108)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = ":"
        '
        'mt
        '
        Me.mt.AutoSize = True
        Me.mt.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mt.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.mt.Location = New System.Drawing.Point(645, 9)
        Me.mt.Name = "mt"
        Me.mt.Size = New System.Drawing.Size(99, 108)
        Me.mt.TabIndex = 8
        Me.mt.Text = "0"
        '
        'ms
        '
        Me.ms.AutoSize = True
        Me.ms.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ms.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ms.Location = New System.Drawing.Point(727, 9)
        Me.ms.Name = "ms"
        Me.ms.Size = New System.Drawing.Size(99, 108)
        Me.ms.TabIndex = 7
        Me.ms.Text = "0"
        '
        'HIT2
        '
        Me.HIT2.AutoSize = True
        Me.HIT2.BackColor = System.Drawing.Color.White
        Me.HIT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HIT2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.HIT2.Location = New System.Drawing.Point(379, 577)
        Me.HIT2.Name = "HIT2"
        Me.HIT2.Size = New System.Drawing.Size(231, 108)
        Me.HIT2.TabIndex = 10
        Me.HIT2.Text = "HIT!"
        '
        'HIT1
        '
        Me.HIT1.AutoSize = True
        Me.HIT1.BackColor = System.Drawing.Color.White
        Me.HIT1.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HIT1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.HIT1.Location = New System.Drawing.Point(1288, 577)
        Me.HIT1.Name = "HIT1"
        Me.HIT1.Size = New System.Drawing.Size(231, 108)
        Me.HIT1.TabIndex = 11
        Me.HIT1.Text = "HIT!"
        '
        'P1Action
        '
        Me.P1Action.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.P1Action.Enabled = False
        Me.P1Action.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.P1Action.ForeColor = System.Drawing.SystemColors.MenuBar
        Me.P1Action.Location = New System.Drawing.Point(1723, 688)
        Me.P1Action.Name = "P1Action"
        Me.P1Action.Size = New System.Drawing.Size(100, 38)
        Me.P1Action.TabIndex = 20
        '
        'ch2
        '
        Me.ch2.Image = Global.Fencing_Proto.My.Resources.Resources.rsz_1fencedownr
        Me.ch2.Location = New System.Drawing.Point(70, 763)
        Me.ch2.Name = "ch2"
        Me.ch2.Size = New System.Drawing.Size(182, 168)
        Me.ch2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.ch2.TabIndex = 21
        Me.ch2.TabStop = False
        '
        'ch1
        '
        Me.ch1.Image = Global.Fencing_Proto.My.Resources.Resources.rsz_1fencedown
        Me.ch1.Location = New System.Drawing.Point(1689, 763)
        Me.ch1.Name = "ch1"
        Me.ch1.Size = New System.Drawing.Size(182, 168)
        Me.ch1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.ch1.TabIndex = 19
        Me.ch1.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Silver
        Me.PictureBox8.Location = New System.Drawing.Point(894, 867)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(137, 117)
        Me.PictureBox8.TabIndex = 18
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Maroon
        Me.PictureBox7.Location = New System.Drawing.Point(1037, 971)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(844, 13)
        Me.PictureBox7.TabIndex = 17
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Maroon
        Me.PictureBox6.Location = New System.Drawing.Point(1037, 867)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(844, 13)
        Me.PictureBox6.TabIndex = 16
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Teal
        Me.PictureBox5.Location = New System.Drawing.Point(43, 971)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(844, 13)
        Me.PictureBox5.TabIndex = 15
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Teal
        Me.PictureBox4.Location = New System.Drawing.Point(43, 867)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(844, 13)
        Me.PictureBox4.TabIndex = 14
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Teal
        Me.PictureBox3.Location = New System.Drawing.Point(43, 886)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(844, 79)
        Me.PictureBox3.TabIndex = 13
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Maroon
        Me.PictureBox2.Location = New System.Drawing.Point(1037, 886)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(844, 79)
        Me.PictureBox2.TabIndex = 12
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Maroon
        Me.PictureBox1.Location = New System.Drawing.Point(13, 123)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1879, 10)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'P2Action
        '
        Me.P2Action.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.P2Action.Enabled = False
        Me.P2Action.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.P2Action.ForeColor = System.Drawing.SystemColors.MenuBar
        Me.P2Action.Location = New System.Drawing.Point(114, 714)
        Me.P2Action.Name = "P2Action"
        Me.P2Action.Size = New System.Drawing.Size(100, 38)
        Me.P2Action.TabIndex = 22
        '
        'PictureBox9
        '
        Me.PictureBox9.Location = New System.Drawing.Point(1110, 798)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(19, 50)
        Me.PictureBox9.TabIndex = 23
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Location = New System.Drawing.Point(807, 798)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(19, 50)
        Me.PictureBox10.TabIndex = 24
        Me.PictureBox10.TabStop = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(634, 218)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(687, 264)
        Me.ListBox1.TabIndex = 25
        '
        'FencingSim
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1904, 1041)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.P2Action)
        Me.Controls.Add(Me.ch2)
        Me.Controls.Add(Me.P1Action)
        Me.Controls.Add(Me.ch1)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.HIT1)
        Me.Controls.Add(Me.HIT2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.mt)
        Me.Controls.Add(Me.ms)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.sst)
        Me.Controls.Add(Me.sss)
        Me.Controls.Add(Me.mst)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.TimerLabel)
        Me.KeyPreview = True
        Me.Name = "FencingSim"
        Me.Text = "0"
        CType(Me.ch2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ch1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TimerLabel As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents StartButton As Button
    Friend WithEvents mst As Label
    Friend WithEvents sss As Label
    Friend WithEvents sst As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents mt As Label
    Friend WithEvents ms As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents HIT2 As Label
    Friend WithEvents HIT1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents ch1 As PictureBox
    Friend WithEvents P1Action As TextBox
    Friend WithEvents ch2 As PictureBox
    Friend WithEvents P2Action As TextBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents ListBox1 As ListBox
End Class
