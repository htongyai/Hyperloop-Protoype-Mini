﻿Imports System.Speech
Public Class FencingSim
    Dim WithEvents reco As New Recognition.SpeechRecognitionEngine
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles TimerLabel.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        reco.SetInputToDefaultAudioDevice()

        Dim gram As New Recognition.SrgsGrammar.SrgsDocument

        Dim speechRule As New Recognition.SrgsGrammar.SrgsRule("color")

        Dim speechList As New Recognition.SrgsGrammar.SrgsOneOf("Start")

        speechRule.Add(speechList)

        gram.Rules.Add(speechRule)

        gram.Root = speechRule

        reco.LoadGrammar(New Recognition.Grammar(gram))

        reco.RecognizeAsync()

    End Sub
    Private Sub reco_RecognizeCompleted(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognizeCompletedEventArgs) Handles reco.RecognizeCompleted

        reco.RecognizeAsync()

    End Sub

    Private Sub reco_SpeechRecognized(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognitionEventArgs) Handles reco.SpeechRecognized

        Select Case e.Result.Text

            Case "Start"
                Timer1.Enabled = True
                reset()
                Restart()

        End Select

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        TimerLabel.Text += 1

        If TimerLabel.Text > 9 Then
            mst.Text += 1
            TimerLabel.Text = 0
        ElseIf mst.Text > 9 Then
            sss.Text += 1
            mst.Text = 0
        ElseIf sss.Text > 9 Then
            sst.Text += 1
            sss.Text = 0
        ElseIf sst.Text > 9 Then

        End If

        Dim totaltime = mt.Text + ms.Text + ":" + sst.Text + sss.Text + ":" + mst.Text + TimerLabel.Text

        If ch2.Location.X + 168 > 1110 Then
            Timer1.Enabled = False
            HIT2.ForeColor = Color.Red
            ListBox1.Items.Add("Player 1 wins at " + totaltime)
            Restart()
        ElseIf ch1.Location.X < 798 Then
            Timer1.Enabled = False
            HIT1.ForeColor = Color.Red
            ListBox1.Items.Add("Player 2 wins at" + totaltime)
            Restart()
        End If


    End Sub
    Public Sub reset()
        TimerLabel.Text = 0
        mst.Text = 0
        sss.Text = 0
        sst.Text = 0
        HIT1.ForeColor = Color.White
        HIT2.ForeColor = Color.White

    End Sub
    Public Sub Restart()
        ch2.Location = New Point(70, 763)
        ch1.Location = New Point(1689, 763)
    End Sub
    Private Sub StartButton_Click(sender As Object, e As EventArgs) Handles StartButton.Click
        reset()
        Timer1.Enabled = True
    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub



    Private Sub FencingSim_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F1 Then


        End If
        If e.KeyCode = Keys.A Then

            P2Action.Text = "Moving"
            ch2.Location = New Point(ch2.Location.X - 50, ch2.Location.Y)


        ElseIf e.KeyCode = Keys.D Then

            P2Action.Text = "Moving"
            ch2.Location = New Point(ch2.Location.X + 50, ch2.Location.Y)

        End If


        If e.KeyCode = Keys.J Then

            P1Action.Text = "Moving"
            ch1.Location = New Point(ch1.Location.X - 50, ch1.Location.Y)


        ElseIf e.KeyCode = Keys.L Then

            P1Action.Text = "Moving"
            ch1.Location = New Point(ch1.Location.X + 50, ch1.Location.Y)

        End If
    End Sub
End Class
